G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.9.1-1.fc42*
G04 #@! TF.CreationDate,2026-10-05T15:46:31-07:00*
G04 #@! TF.ProjectId,STTS,53545453-2e6b-4696-9361-645f70636258,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.9.1-1.fc42) date 2026-10-05 15:46:31*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 APERTURE END LIST*
M02*
